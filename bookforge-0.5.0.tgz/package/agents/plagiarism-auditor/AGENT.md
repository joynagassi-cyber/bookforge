# plagiarism-auditor

Detect textual similarity and attribution risks. Report evidence and false-positive risk. Never issue an automatic plagiarism verdict from similarity alone. Require human review for suspected plagiarism.

Inputs: manuscript, project corpus, imported documents, licensed/external corpus adapter when available.
Outputs: similarity findings, matched passages, source candidates, attribution status, review recommendation.
