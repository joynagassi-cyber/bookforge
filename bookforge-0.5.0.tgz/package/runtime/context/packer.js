import { search } from '../retrieval.js';
import { route } from './router.js';
export async function pack(project,opts={}){
  const decision=route(project,opts); const catalogs=[...decision.required,...decision.optional]; const entries=[];
  for(const c of catalogs){ const found=await search(project,opts.task||'',{catalog:c,limit:opts.perCatalog||8}); entries.push(...found.map(x=>({...x,retrieval_role:decision.required.includes(c)?'required':'optional'}))); }
  const seen=new Set(); const unique=entries.filter(x=>!seen.has(x.id)&&(seen.add(x.id),true));
  return {version:'0.5.0',task_id:`ctx-${Date.now()}`,agent:opts.agent||null,workflow:opts.workflow||null,route:decision,retrieval:{mode:'deterministic-first',levels:[0,1,2,3,4,5]},entries:unique.slice(0,opts.maxEntries||60),token_budget:opts.budget||5000};
}
