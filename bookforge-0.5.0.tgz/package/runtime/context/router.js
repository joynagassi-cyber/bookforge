import fs from 'node:fs';
import path from 'node:path';
import { readJson, bfPath } from '../core/io.js';

function safe(p){ try{return readJson(p)}catch{return null} }
export function loadMaps(project){
  const root=bfPath(project,'knowledge','indexes');
  return {agents:safe(path.join(root,'agent-catalog-map.json'))||{},workflows:safe(path.join(root,'workflow-catalog-map.json'))||{},catalogs:safe(path.join(root,'catalog-index.json'))||{},entries:safe(path.join(root,'entry-index.json'))||{}};
}
function flatten(v){ if(Array.isArray(v)) return v; if(v&&typeof v==='object'){return Object.values(v).flatMap(flatten)} return typeof v==='string'?[v]:[]; }
export function route(project,{task='',agent=null,workflow=null,genre=null,bookType=null,audience=null}={}){
  const m=loadMaps(project); const required=new Set(); const optional=new Set();
  for(const src of [m.agents?.[agent],m.workflows?.[workflow]]){
    if(!src) continue;
    flatten(src.required||src).forEach(x=>required.add(x));
    flatten(src.optional||[]).forEach(x=>optional.add(x));
  }
  const q=`${task} ${genre||''} ${bookType||''} ${audience||''}`.toLowerCase();
  const hints=[]; if(/dialogue|dialogue|conversation/.test(q)) hints.push('dialogue','subtext','voice');
  if(/character|personnage/.test(q)) hints.push('character','character-arcs','relationships');
  if(/chapter|chapitre|scene|scène/.test(q)) hints.push('scenes','beats','conflict','stakes','pacing');
  if(/research|recherche|claim|citation|source/.test(q)) hints.push('research','sources','claims');
  if(/edit|revision|révision|quality|qualité/.test(q)) hints.push('quality','anti-patterns','cliches','ai-slop','originality');
  hints.forEach(x=>required.add(x));
  return {version:'0.5.0',agent,workflow,filters:{genre,bookType,audience},required:[...required].sort(),optional:[...optional].sort(),task};
}
