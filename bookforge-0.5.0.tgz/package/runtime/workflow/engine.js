import fs from 'node:fs';
import path from 'node:path';
import { readJson, writeJson, bfPath, mkdir } from '../core/io.js';
import { pack } from '../context/packer.js';

function loadWorkflow(project,id){
  const manifest=readJson(path.resolve(process.cwd(),'manifests','workflows.json')).find(x=>x.id===id);
  if(!manifest) throw new Error(`Unknown workflow: ${id}`);
  return manifest;
}
export async function plan(project,id,opts={}){
  const wf=loadWorkflow(project,id); const context=await pack(project,{...opts,workflow:id});
  return {version:'0.5.0',workflow:{id:wf.id,version:wf.version,phase:wf.phase,purpose:wf.purpose},state:'READY',context,contract:{entry:wf.entry,requires:wf.requires,human_approval:wf.human_approval}};
}
export function start(project,planData){
  const runId=`run-${Date.now()}`; const p=bfPath(project,'runtime','runs',`${runId}.json`); mkdir(path.dirname(p)); const run={run_id:runId,...planData,state:'CONTEXT_BUILT',started_at:new Date().toISOString()}; writeJson(p,run); return run;
}
export function transition(project,runId,state,details={}){
  const p=bfPath(project,'runtime','runs',`${runId}.json`); if(!fs.existsSync(p)) throw new Error(`Unknown run ${runId}`); const r=readJson(p); r.state=state; r.updated_at=new Date().toISOString(); Object.assign(r,details); writeJson(p,r); return r;
}
