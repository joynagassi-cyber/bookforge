import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto';
import { readJson, bfPath, mkdir } from '../core/io.js';
import { create as jsonl } from '../providers/jsonl.js';
import { create as neo4j } from '../providers/neo4j.js';

function eventFiles(project){const d=bfPath(project,'events'); if(!fs.existsSync(d))return []; return fs.readdirSync(d).filter(x=>x.endsWith('.json')).sort().map(x=>path.join(d,x));}
export async function sync(project,{provider=null}={}){
  let cfg={provider:'jsonl'}; const p=bfPath(project,'graph','provider.json'); if(fs.existsSync(p)) cfg=readJson(p);
  const name=provider||cfg.provider||'jsonl'; const sink=name==='neo4j'?await neo4j(project,cfg):jsonl(project);
  const marker=bfPath(project,'graph','sync-state.json'); const state=fs.existsSync(marker)?readJson(marker):{events:{}}; let applied=0,skipped=0;
  for(const fp of eventFiles(project)){const e=readJson(fp); const digest=crypto.createHash('sha256').update(JSON.stringify(e)).digest('hex'); if(state.events[e.event_id]===digest){skipped++;continue;} await sink.apply(e); state.events[e.event_id]=digest; applied++;}
  mkdir(path.dirname(marker)); fs.writeFileSync(marker,JSON.stringify({provider:name,updated_at:new Date().toISOString(),events:state.events},null,2)+'\n'); if(sink.close) await sink.close();
  return {status:'ok',provider:name,applied,skipped};
}
