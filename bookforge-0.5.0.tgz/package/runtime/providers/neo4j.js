export async function create(project,config={}){
  let neo4j; try{ neo4j=await import('neo4j-driver'); }catch{ throw new Error('Neo4j provider requires optional dependency neo4j-driver'); }
  const uri=config.uri||process.env.NEO4J_URI||'neo4j://localhost'; const user=config.username||process.env.NEO4J_USERNAME||'neo4j'; const pass=config.password||process.env.NEO4J_PASSWORD;
  if(!pass) throw new Error('NEO4J_PASSWORD is required for neo4j provider'); const driver=neo4j.default.driver(uri,neo4j.default.auth.basic(user,pass));
  return {name:'neo4j',async apply(event){const s=driver.session({database:config.database||process.env.NEO4J_DATABASE}); try{await s.run('MERGE (e:BookForgeEvent {event_id:$id}) SET e += $props',{id:event.event_id,props:{operation:event.operation,source_artifact:event.source_artifact||null,source_hash:event.source_hash||null,timestamp:event.timestamp||null}}); return {ok:true,provider:'neo4j',event_id:event.event_id};}finally{await s.close();}},async close(){await driver.close();}};
}
