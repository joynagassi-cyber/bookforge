import fs from 'node:fs'; import path from 'node:path'; import { mkdir, bfPath } from '../core/io.js';
export function create(project){ const out=bfPath(project,'graph','events.jsonl'); mkdir(path.dirname(out)); return {name:'jsonl',async apply(event){fs.appendFileSync(out,JSON.stringify(event)+'\n'); return {ok:true,provider:'jsonl',path:out};}}; }
