import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { execFileSync } from 'node:child_process';
import { register } from './registry.js';
import { mkdir } from '../core/io.js';

function copyDir(src,dst){ mkdir(path.dirname(dst)); fs.cpSync(src,dst,{recursive:true}); }
function readManifest(dir){
  const candidates=['plugin.json','manifest.json','module.json'];
  for(const f of candidates){const p=path.join(dir,f); if(fs.existsSync(p)) return JSON.parse(fs.readFileSync(p,'utf8'));}
  throw new Error(`No plugin manifest found in ${dir}`);
}
function stageNpm(spec){
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'bookforge-plugin-'));
  execFileSync('npm',['pack',spec,'--pack-destination',tmp],{stdio:'ignore'});
  const tar=fs.readdirSync(tmp).find(x=>x.endsWith('.tgz')); if(!tar) throw new Error('npm pack produced no archive');
  execFileSync('tar',['-xzf',path.join(tmp,tar),'-C',tmp]); return path.join(tmp,'package');
}
function stageGithub(spec){
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'bookforge-git-'));
  const url=spec.replace(/^github:/,'https://github.com/')+(spec.replace(/^github:/,'').endsWith('.git')?'':'.git');
  execFileSync('git',['clone','--depth','1',url,path.join(tmp,'repo')],{stdio:'ignore'}); return path.join(tmp,'repo');
}
export function install(project,spec,{enable=true}={}){
  if(!spec) throw new Error('plugin source is required');
  let sourceDir=spec;
  if(spec.startsWith('npm:')) sourceDir=stageNpm(spec.slice(4));
  else if(spec.startsWith('github:')) sourceDir=stageGithub(spec);
  else if(spec.startsWith('file:')) sourceDir=spec.slice(5);
  sourceDir=path.resolve(sourceDir);
  if(!fs.existsSync(sourceDir)) throw new Error(`Plugin source not found: ${sourceDir}`);
  const manifest=readManifest(sourceDir); const dst=path.join(project,'bookforge','plugins',manifest.id); copyDir(sourceDir,dst);
  return register(project,manifest,{source:spec,enabled:enable});
}
