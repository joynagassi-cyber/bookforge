import fs from 'node:fs';
import path from 'node:path';
import { list } from './registry.js';
import { mkdir, writeText, bfPath } from '../core/io.js';

function items(v){ return Array.isArray(v)?v:Object.keys(v||{}); }
export function activate(project,{host='generic'}={}){
  const plugins=list(project).filter(p=>p.enabled!==false); const generated=[];
  const root=host==='claude-code'?'.claude/skills':(['cursor','windsurf','github-copilot'].includes(host)?'.agents/skills':host==='antigravity'?'.agent/skills':'bookforge/generated/skills');
  for(const p of plugins){
    const eps=p.entrypoints||{};
    for(const kind of ['agents','workflows','skills']){
      for(const item of items(eps[kind])){
        const id=typeof item==='string'?item:item.id; if(!id)continue;
        const dir=path.join(project,root,`bookforge-${p.id}-${id}`); mkdir(dir);
        writeText(path.join(dir,'SKILL.md'),`---\nname: bookforge-${p.id}-${id}\ndescription: BookForge ${kind.slice(0,-1)} provided by ${p.id}\n---\n\n# BookForge plugin launcher\n\nLoad the canonical BookForge project state first.\nPlugin: ${p.id}\nComponent: ${id}\nType: ${kind.slice(0,-1)}\n\nFollow the component contract from bookforge/plugins/${p.id}/ and use BookForge context packets rather than inventing context.\n`);
        generated.push({plugin:p.id,kind,id,path:path.relative(project,dir)});
      }
    }
  }
  const out=bfPath(project,'runtime','plugin-activation.json'); mkdir(path.dirname(out)); fs.writeFileSync(out,JSON.stringify({version:'0.5.0',host,generated_at:new Date().toISOString(),generated},null,2)+'\n');
  return {host,generated};
}
