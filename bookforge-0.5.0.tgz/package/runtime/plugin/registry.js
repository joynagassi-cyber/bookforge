import fs from 'node:fs';
import path from 'node:path';
import { mkdir, readJson, writeJson, bfPath } from '../core/io.js';

const idRe=/^[a-z0-9][a-z0-9._-]+$/;
function validateManifest(m){
  const errors=[];
  if(!m?.id || !idRe.test(m.id)) errors.push('invalid id');
  if(!m?.version) errors.push('missing version');
  if(!m?.kind) errors.push('missing kind');
  if(!m?.entrypoints || typeof m.entrypoints!=='object') errors.push('missing entrypoints');
  return errors;
}
export function registryPath(project){ return bfPath(project,'plugins','registry.json'); }
export function loadRegistry(project){
  const p=registryPath(project); if(!fs.existsSync(p)) return {schema_version:'1.0.0',plugins:[]};
  return readJson(p);
}
export function saveRegistry(project,r){ mkdir(path.dirname(registryPath(project))); writeJson(project && registryPath(project),r); }
export function register(project,manifest,{source=null,enabled=true}={}){
  const errors=validateManifest(manifest); if(errors.length) throw new Error(`Plugin manifest invalid: ${errors.join(', ')}`);
  const r=loadRegistry(project); const now=new Date().toISOString();
  const entry={...manifest,source,enabled,registered_at:now};
  const i=r.plugins.findIndex(x=>x.id===manifest.id); if(i>=0) r.plugins[i]=entry; else r.plugins.push(entry);
  r.plugins.sort((a,b)=>a.id.localeCompare(b.id)); saveRegistry(project,r); return entry;
}
export function list(project){ return loadRegistry(project).plugins; }
export function get(project,id){ return list(project).find(x=>x.id===id)||null; }
export function enable(project,id,value=true){ const r=loadRegistry(project); const p=r.plugins.find(x=>x.id===id); if(!p) throw new Error(`Unknown plugin: ${id}`); p.enabled=value; saveRegistry(project,r); return p; }
export function remove(project,id){ const r=loadRegistry(project); const before=r.plugins.length; r.plugins=r.plugins.filter(x=>x.id!==id); saveRegistry(project,r); return before!==r.plugins.length; }
