# BookForge — Context Engineering Framework for AI-Assisted Book Creation

BookForge is a platform-agnostic, specification-driven framework for turning a general-purpose AI agent
into a disciplined book-production system capable of working on long manuscripts without relying on chat
history as the source of truth.

The framework is designed around:

- artifact-first continuity;
- progressive context disclosure;
- specialized agents and workflows;
- scale-adaptive execution;
- deterministic readiness gates;
- reusable knowledge catalogs;
- quality and integrity validation;
- IDE/CLI adapters instead of vendor lock-in.

## Supported execution model

The core does not depend on a specific IDE, CLI, model, provider, or agent runtime.

Examples that can be adapted:

- Antigravity
- Kiro
- Devin
- Cursor
- Claude Code
- Codex CLI
- OpenCode
- KiloCode
- other systems supporting project instructions, files, skills, prompts, workflows, or sub-agents.

## Design principle

The model is replaceable. The artifacts are canonical.

An agent may disappear, a chat may be reset, and the runtime may change. The project remains reconstructable
from the files in `bookforge/` and the manuscript workspace.

## Current package

This initial package contains the framework architecture, contracts, agent/workflow catalog, quality
model, adapter model, and extensible knowledge catalogs. It is the foundation for the implementation
of the full skill library.

See:

- `docs/ARCHITECTURE.md`
- `docs/WORKFLOW.md`
- `docs/CONTEXT-ENGINEERING.md`
- `docs/QUALITY-GATES.md`
- `docs/EXTENSION-MODEL.md`
- `docs/ADAPTER-CONTRACT.md`
- `catalogs/`
- `skills/`
- `agents/`
- `workflows/`


## Knowledge System (v0.3.0 candidate)

BookForge now carries a non-destructive integration of the 54-catalog Master Specification under `knowledge/`. Legacy catalogs remain intact. Catalog packages expose manifests, schemas and seed entries; indexes support deterministic retrieval.

Quality integrity is explicit: similarity/originality, AI-slop, cliché risk and human-voice refinement are separate controls. Similarity is evidence for review, not an automatic plagiarism verdict; human-voice refinement is not AI-detector evasion.

## Runtime v0.5 — operational installation

From a GitHub repository:

```bash
npx --yes github:OWNER/BOOKFORGE install --host auto
```

After publishing the package to npm, the same runtime becomes:

```bash
npx bookforge install --host auto
```

For maximum host coverage:

```bash
npx bookforge install --host all
```

The installer creates the canonical `bookforge/` project state and generates only the thin launcher skills required by the selected host. The semantic agent/workflow contracts remain identical across hosts.

### Runtime services

```text
Plugin Registry
      ↓
Workflow Engine
      ↓
Context Router / Packer
      ↓
Agent Host
      ↓
Artifacts + Events
      ↓
Graph Synchronizer
      ↓
JSONL / Neo4j / optional temporal graph layer
```

### Plugin installation

```bash
bookforge plugin add --source github:OWNER/bookforge-plugin
bookforge plugin list
bookforge plugin enable narrative
bookforge plugin disable narrative
bookforge plugin remove narrative
```

### Context and workflows

```bash
bookforge route "write chapter 4" --agent writer --workflow draft-chapter
bookforge context-pack "write chapter 4" --agent writer --workflow draft-chapter
bookforge workflow plan draft-chapter "write chapter 4" --agent writer
bookforge workflow run draft-chapter "write chapter 4" --agent writer
```

### Live graph synchronization

```bash
bookforge watch --sync
```

This watches canonical artifacts, emits idempotent events and synchronizes the configured graph projection. JSONL is the zero-dependency default. Neo4j is an optional provider; the official Neo4j MCP server can also be exposed to compatible AI hosts. Graphiti is supported conceptually as an optional temporal context-graph layer; it should remain a projection rather than the canonical book store.
